```python
import networkx as nx
import pylab as plt
import numpy as np

inf = float('inf')
nodes = np.array([[0, 9, 2, 4, 7],
                  [9, 0, 3, 4, inf],
                  [2, 3, 0, 8, 4],
                  [4, 4, 8, 0, 6],
                  [7, inf, 4, 6, 0]])
G = nx.Graph()
G.add_nodes_from(['V1', 'V2', 'V3', 'V4', 'V5'])
for i in range(5):
    for j in range(5):
        if nodes[i, j] != inf and i != j:
            G.add_edge('V'+str(i+1), 'V'+str(j+1), weight=int(nodes[i, j]))
pos = nx.shell_layout(G)
edge_labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx(G, pos)
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)
plt.show()

```


    
![png](output_0_0.png)
    

